const searchBtn = document.getElementById ('searchBtn');
const digimonInput = document.getElementById('digimonInput');
const card = document.getElementById('digimonCard');
const messageBox = document.getElementById('messageBox');

async function buscarDigimon() {
    const busqueda = digimonInput.value.trim();
    
    // Validación de campo vacío
    if (!busqueda) {
        messageBox.textContent =
            'Por favor, escribe un nombre o un número de ID.';
        messageBox.className = 'alert alert-warning';
        card.classList.add('d-none');
        return;
    }

    // Mostrar estado de carga usando utilidades de Bootstrap
    messageBox.textContent = 'Conectando con la API remota...';
    messageBox.className = 'alert alert-info';
    card.classList.add('d-none');

    try {
        // Enlace de la API para extraer la información de manera remota
        const url =
            `https://digi-api.com/api/v1/digimon/${encodeURIComponent(busqueda)}`;

        const respuesta = await fetch(url);
        console.log('Respuesta HTTP:', respuesta.status);
        console.log('URL consultada:', url);

        // Comprobar si la solicitud fue exitosa
        if (!respuesta.ok) {
            if (respuesta.status === 404) {
                throw new Error(
                    'No se encontró ese Digimon. ¡Intenta otra vez!'
                );
            }

            throw new Error(
                `Error al consultar la API: ${respuesta.status}`
            );
        }

        // convertir la repuesta a formato JSON
        const datos = await respuesta.json();

        // Obtener los elementos HTML de la targeta
        const digimonImg = document.getElementById('digimonImg');
        const digimonName = document.getElementById('digimonName');
        const digimonId = document.getElementById('digimonId');

        // Obtener la primera imagen disponible
        const imagen = datos.images?.[0]?.href;

        // Mostrar los datos del Digimon
        digimonName.textContent = datos.name;
        digimonId.textContent = datos.id;

        if (imagen) {
            digimonImg.src = imagen;
            digimonImg.alt = `Imagen de ${datos.name}`;
            digimonImg.classList.remove('d-none');
        } else {
            digimonImg.removeAttribute('src');
            digimonImg.alt = 'Imagen no disponible';
            digimonImg.classList.add('d-none');
        }

        // Ocultar el mensaje de carga
        messageBox.classList.add('d-none');

        // Mostrar la tarjeta del Digimon
        card.classList.remove('d-none');
        console.log('¡Tarjeta mostrada correctamente!');

    } catch (error) {

        // Mostrar error en pantalla
        messageBox.textContent =
            error instanceof TypeError
                ? 'No se pudo conectar con la API. Revisa tu conexión.'
                : error.message;

        messageBox.className = 'alert alert-danger';
        card.classList.add('d-none');

        console.error('Error al buscar el Digimon:', error);
    }
}

// Ejecutar la busqueda al hacer clic en el boton
searchBtn.addEventListener('click', buscarDigimon);

// Ejecutar la busqueda al precionar Enter
digimonInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
        buscarDigimon();
    }
});


// link de la pagina de la API = https://digi-api.com/